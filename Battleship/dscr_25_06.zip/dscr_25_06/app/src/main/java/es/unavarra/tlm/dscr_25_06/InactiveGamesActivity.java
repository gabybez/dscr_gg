package es.unavarra.tlm.dscr_25_06;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.loopj.android.http.AsyncHttpClient;

import cz.msebera.android.httpclient.Header;

/**
 * Activity que muestra las PARTIDAS INACTIVAS (finished/cancelled):
 * - GET /v2/game/inactive con X-Authentication
 * - Reutiliza mismo layout y adapter que la de activas
 */
public class InactiveGamesActivity extends AppCompatActivity {

    private ProgressBar pb;
    private TextView tvEmpty;
    private ListView lv;
    private GameListAdapter adapter;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_games_list);
        setTitle(getString(R.string.title_games_inactive));

        pb = findViewById(R.id.pb);
        tvEmpty = findViewById(R.id.tvEmpty);
        lv = findViewById(R.id.lvGames);

        adapter = new GameListAdapter(this);
        lv.setAdapter(adapter);

        cargar();
    }

    private void cargar() {
        String token = SessionManager.getToken(this);
        if (token == null) {
            Toast.makeText(this, "Sesión caducada", Toast.LENGTH_LONG).show();
            return;
        }

        pb.setVisibility(View.VISIBLE);
        tvEmpty.setVisibility(View.GONE);

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("X-Authentication", token);

        String url = new ListarInactivosRequest().buildUrl(getString(R.string.api_game_inactive));
        client.get(url, new ListarInactivosResponseHandler(this, games -> {
            pb.setVisibility(View.GONE);
            adapter.setItems(games);

            if (games == null || games.isEmpty()) {
                tvEmpty.setVisibility(View.VISIBLE);
                tvEmpty.setText(getString(R.string.list_empty_inactive));
            }
        }) {
            @Override public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                super.onFailure(statusCode, headers, responseBody, error);
                pb.setVisibility(View.GONE);
                tvEmpty.setVisibility(View.VISIBLE);
                tvEmpty.setText(getString(R.string.list_error_load, statusCode));
            }
        });
    }
}
