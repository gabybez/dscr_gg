package es.unavarra.tlm.dscr_25_06;

/**
 * "Request" minimalista para seguir tu patrón de separar clases:
 * - En GET no hay body; solo necesitamos construir la URL.
 * - El valor viene de strings.xml: @string/api_game_active
 */
public class ListarActivosRequest {
    public String buildUrl(String baseActiveUrl) {
        // GET /v2/game/active
        return baseActiveUrl;
    }
}
