package es.unavarra.tlm.dscr_25_06;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.loopj.android.http.AsyncHttpClient;

import cz.msebera.android.httpclient.Header;

/**
 * Activity que muestra las PARTIDAS ACTIVAS:
 * - GET /v2/game/active con cabecera X-Authentication
 * - Usa ListView + BaseAdapter (GameListAdapter)
 * - Textos de título/vacío/error en strings.xml
 */
public class ActiveGamesActivity extends AppCompatActivity {

    private ProgressBar pb;
    private TextView tvEmpty;
    private ListView lv;
    private GameListAdapter adapter;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_games_list);
        setTitle(getString(R.string.title_games_active));

        // Referencias UI
        pb = findViewById(R.id.pb);
        tvEmpty = findViewById(R.id.tvEmpty);
        lv = findViewById(R.id.lvGames);

        // Adapter para el ListView
        adapter = new GameListAdapter(this);
        lv.setAdapter(adapter);

        // Carga inicial
        cargar();
    }

    /** Llama a la API y alimenta el adapter */
    private void cargar() {
        String token = SessionManager.getToken(this);
        if (token == null) {
            Toast.makeText(this, "Sesión caducada", Toast.LENGTH_LONG).show();
            return;
        }

        pb.setVisibility(View.VISIBLE);
        tvEmpty.setVisibility(View.GONE);

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("X-Authentication", token);

        String url = new ListarActivosRequest().buildUrl(getString(R.string.api_game_active));
        client.get(url, new ListarActivosResponseHandler(this, games -> {
            // Éxito: ocultamos loader y volcamos al adapter
            pb.setVisibility(View.GONE);
            adapter.setItems(games);

            // Si está vacío, mostramos mensaje
            if (games == null || games.isEmpty()) {
                tvEmpty.setVisibility(View.VISIBLE);
                tvEmpty.setText(getString(R.string.list_empty_active));
            }
        }) {
            @Override public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                // Devolvemos comportamiento base (Toast) y además gestionamos UI
                super.onFailure(statusCode, headers, responseBody, error);
                pb.setVisibility(View.GONE);
                tvEmpty.setVisibility(View.VISIBLE);
                tvEmpty.setText(getString(R.string.list_error_load, statusCode));
            }
        });
    }
}
