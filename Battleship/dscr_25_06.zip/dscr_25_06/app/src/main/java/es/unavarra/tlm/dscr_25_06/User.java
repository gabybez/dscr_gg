package es.unavarra.tlm.dscr_25_06;

/**
 * Representa al usuario que enviamos desde login/register.
 * Este objeto "mapea" uno a uno el JSON { id, username } que llega de la API.
 * Gson creará una instancia de esta clase a partir del JSON sin que tengamos que escribir código extra.
 */
public class User {
    // Campos privados porque los exponemos con getters (buena práctica de encapsulación)
    private long id;
    private String username;

    // Getters: Gson setea por reflexión; nosotros solo necesitamos leerlos
    public long getId() { return id; }
    public String getUsername() { return username; }
}
