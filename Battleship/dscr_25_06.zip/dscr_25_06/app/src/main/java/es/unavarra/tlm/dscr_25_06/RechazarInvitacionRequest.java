package es.unavarra.tlm.dscr_25_06;

/**
 * Request para rechazar/cancelar.
 * DELETE /v2/game/{game_id}
 *  - en estado 'waiting', para ti es "rechazar"
 *  - si lo creaste tú, puede considerarse "cancelar"
 */
public class RechazarInvitacionRequest {
    private final long gameId;
    public RechazarInvitacionRequest(long gameId) { this.gameId = gameId; }
    public String buildUrl(String baseGameUrl) {
        return baseGameUrl + "/" + gameId;
    }
}
