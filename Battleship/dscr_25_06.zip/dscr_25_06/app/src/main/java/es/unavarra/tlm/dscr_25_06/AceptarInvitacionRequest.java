package es.unavarra.tlm.dscr_25_06;

/**
 * Request para aceptar invitación (no lleva cuerpo, sólo path param).
 * POST /v2/game/{game_id}
 */
public class AceptarInvitacionRequest {
    private final long gameId;
    public AceptarInvitacionRequest(long gameId) { this.gameId = gameId; }
    public String buildUrl(String baseGameUrl) { // base = https://.../v2/game
        return baseGameUrl + "/" + gameId;
    }
}
