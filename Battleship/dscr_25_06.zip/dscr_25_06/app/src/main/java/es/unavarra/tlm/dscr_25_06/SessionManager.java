package es.unavarra.tlm.dscr_25_06;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Guarda y recupera la sesión en SharedPreferences (almacenamiento simple de clave-valor).
 * Así, si cierro y abro la app, sigo "logueado" hasta que haga logout.
 */
public final class SessionManager {
    private static final String PREFS = "Config";          // Nombre de fichero de preferencias
    private static final String KEY_TOKEN = "token";        // Clave para el token
    private static final String KEY_EXPIRES = "valid_until";// Caducidad (opcional)
    private static final String KEY_USER = "username";      // Por comodidad
    private static final String KEY_USER_ID = "user_id";    // Por comodidad

    /**
     * Guarda de golpe user+session tal y como viene en AuthBundle.
     * Se llama en onSuccess de LoginActivity/RegisterActivity.
     */
    public static void save(Context ctx, AuthBundle b) {
        if (b == null || b.getSession() == null || b.getUser() == null) return;
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit()
                .putString(KEY_TOKEN, b.getSession().getToken())
                .putString(KEY_EXPIRES, b.getSession().getValid_until())
                .putString(KEY_USER, b.getUser().getUsername())
                .putLong(KEY_USER_ID, b.getUser().getId())
                .apply();
    }

    /** Recupera el token (si no hay → null). Se usa para saber si hay sesión activa. */
    public static String getToken(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TOKEN, null);
    }

    /** Limpia_todo (logout local). Se llama tras DELETE /v2/session o si queremos forzar relogin. */
    public static void clear(Context ctx) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply();
    }
}
