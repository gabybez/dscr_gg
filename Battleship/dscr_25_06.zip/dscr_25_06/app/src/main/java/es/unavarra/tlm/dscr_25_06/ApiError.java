package es.unavarra.tlm.dscr_25_06;

/**
 * Cuando el backend responde 400 (Bad Request), en tu API devuelve { "code": "..." }.
 * Parseamos ese JSON a esta clase para poder mostrar mensajes de error claros.
 */
public class ApiError {
    public String code; // p.ej. INVALID_CREDENTIALS, USERNAME_NOT_AVAILABLE, etc.
}
