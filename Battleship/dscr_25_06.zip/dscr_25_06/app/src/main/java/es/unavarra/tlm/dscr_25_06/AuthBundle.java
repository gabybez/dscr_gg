package es.unavarra.tlm.dscr_25_06;

/**
 * Muchas APIs devuelven en login/register un "paquete" con user+session.
 * Aquí mapeamos { user: {...}, session: {...} } a una clase Java para parsearlo de golpe con Gson.
 */
public class AuthBundle {
    private User user;
    private Session session;

    public User getUser() { return user; }
    public Session getSession() { return session; }
}
