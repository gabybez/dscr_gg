package es.unavarra.tlm.dscr_25_06;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import cz.msebera.android.httpclient.Header;

/**
 * Pantalla principal tras login/registro.
 * - Comprueba al crear que haya token; si no, te saca a Login (o Welcome).
 * - Botón "LOG OUT": DELETE /v2/session con X-Authentication + limpiar sesión local.
 */
public class MainActivity extends AppCompatActivity {

    private Button btnNewGame, btnPartidasOn, btnPartidasOff, btnSalir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // usa tu layout actual

        // Referencias a los botones que ya tenías en tu layout
        btnNewGame     = findViewById(R.id.btn_New_game);
        btnPartidasOn  = findViewById(R.id.btn_Partidas_on);
        btnPartidasOff = findViewById(R.id.btn_Partidas_off);
        btnSalir       = findViewById(R.id.Btn_salir);

        // NEW GAME -> invitar a un usuario (CrearPartidaActivity)
        btnNewGame.setOnClickListener(v ->
                startActivity(new Intent(this, CrearPartidaActivity.class)));

        // PARTIDAS EN CURSO -> abre la lista de activos (InvitacionesActivity)
        // Dentro de esa pantalla tendrás los botones ACEPTAR/RECHAZAR por invitación.
        btnPartidasOn.setOnClickListener(v ->
                startActivity(new Intent(this, InvitacionesActivity.class)));

        // PARTIDAS FINALIZADAS (opcional): podrías abrir otra pantalla que llame a /v2/game/inactive
        btnPartidasOff.setOnClickListener(v ->
                Toast.makeText(this, "Pendiente: listar finalizadas (/v2/game/inactive)", Toast.LENGTH_SHORT).show());

        // LOG OUT -> DELETE /v2/session
        btnSalir.setOnClickListener(v -> doLogout());
    }

    /** Hace logout REAL en servidor y limpia la sesión local. */
    private void doLogout() {
        String token = SessionManager.getToken(this);
        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("X-Authentication", token); // cabecera de auth que pide la API

        // DELETE /v2/session
        client.delete(this, getString(R.string.api_login_session), new AsyncHttpResponseHandler() {
            @Override public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                SessionManager.clear(MainActivity.this);
                goToLogin();
            }
            @Override public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                // Aunque falle (sin red, etc.), limpia local para forzar re-login
                SessionManager.clear(MainActivity.this);
                goToLogin();
            }
        });
    }

    /** Vuelve a la pantalla de identificación y limpia el back stack. */
    private void goToLogin() {
        // Si usas WelcomeActivity, cámbialo aquí
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }
}
