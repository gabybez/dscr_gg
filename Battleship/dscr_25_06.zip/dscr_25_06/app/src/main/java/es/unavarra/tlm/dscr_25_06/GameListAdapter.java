package es.unavarra.tlm.dscr_25_06;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Adapter clásico (BaseAdapter) para pintar una lista de GameInfo
 * en el layout row_game.xml.
 *
 * Patrón ViewHolder: evitamos findViewById en cada scroll.
 */
public class GameListAdapter extends BaseAdapter {

    private final Context ctx;
    private final LayoutInflater inflater;
    private final List<GameInfo> data = new ArrayList<>();

    public GameListAdapter(Context ctx) {
        this.ctx = ctx;
        this.inflater = LayoutInflater.from(ctx);
    }

    /** Sustituye la lista y notifica cambios al ListView */
    public void setItems(List<GameInfo> items) {
        data.clear();
        if (items != null) data.addAll(items);
        notifyDataSetChanged();
    }

    @Override public int getCount() { return data.size(); }
    @Override public GameInfo getItem(int position) { return data.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        VH h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.row_game, parent, false);
            h = new VH(convertView);
            convertView.setTag(h);
        } else {
            h = (VH) convertView.getTag();
        }

        GameInfo g = getItem(position);

        // Título: nombre del enemigo si existe; si no, un fallback "Juego #id"
        String title = (g.getEnemy() != null && g.getEnemy().getUsername() != null)
                ? g.getEnemy().getUsername()
                : ctx.getString(R.string.row_title_fallback, g.id);
        h.tvTitle.setText(title);

        // Subtítulo: estado + pista contextual, todo con strings.xml (fácil de traducir)
        String state = g.state; // literal original del API
        String extra = "";
        if ("waiting".equalsIgnoreCase(state)) {
            extra = g.your_turn
                    ? ctx.getString(R.string.row_sub_waiting_mine)
                    : ctx.getString(R.string.row_sub_waiting_theirs);
            state = ctx.getString(R.string.state_waiting);
        } else if ("placing".equalsIgnoreCase(state)) {
            extra = g.your_turn
                    ? ctx.getString(R.string.row_sub_placing_mine)
                    : ctx.getString(R.string.row_sub_placing_theirs);
            state = ctx.getString(R.string.state_placing);
        } else if ("started".equalsIgnoreCase(state)) {
            extra = g.your_turn
                    ? ctx.getString(R.string.row_sub_started_mine)
                    : ctx.getString(R.string.row_sub_started_theirs);
            state = ctx.getString(R.string.state_started);
        } else if ("finished".equalsIgnoreCase(state)) {
            state = ctx.getString(R.string.state_finished);
        } else if ("cancelled".equalsIgnoreCase(state)) {
            state = ctx.getString(R.string.state_cancelled);
        }

        h.tvSubtitle.setText(extra.isEmpty() ? state : (state + " " + extra));
        return convertView;
    }

    /** ViewHolder: referencias cacheadas a los TextViews del row */
    static class VH {
        final TextView tvTitle, tvSubtitle;
        VH(View v) {
            tvTitle = v.findViewById(R.id.tvTitle);
            tvSubtitle = v.findViewById(R.id.tvSubtitle);
        }
    }
}
