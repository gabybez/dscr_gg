package es.unavarra.tlm.dscr_25_06;

public class GameInfo {
    // Campos según el spec
    public long id;
    public String state;       // waiting | placing | started | finished | cancelled
    public User you;           // tú
    public User enemy;         // el otro
    public boolean your_turn;  // en 'waiting': true => debes responder tú; false => espera el rival

    // === Getters para que el adapter/handlers puedan acceder de forma segura ===
    public long getId() { return id; }
    public String getState() { return state; }
    public User getYou() { return you; }
    public User getEnemy() { return enemy; }
    public boolean isYour_turn() { return your_turn; } // por si lo necesitas como getter

    // === Helpers de conveniencia (los que ya tenías) ===
    public boolean isWaiting() { return "waiting".equalsIgnoreCase(state); }
    public boolean isPendingMyDecision() { return isWaiting() && your_turn; }
    public boolean isPendingTheirDecision() { return isWaiting() && !your_turn; }
}
